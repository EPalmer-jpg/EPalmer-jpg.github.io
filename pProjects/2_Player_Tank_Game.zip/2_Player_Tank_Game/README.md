# 2-Player-Tank-Game
simple game where 2 people fight against each other with tanks.
Player 1 uses the wasd keys for movement and space to fire a shot
Player 2 uses the arrow keys for movement and 5 or numberpad 5 to fire a shot
