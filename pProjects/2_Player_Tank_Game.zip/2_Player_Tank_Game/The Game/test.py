# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 10:06:53 2019

@author: evanc
"""
a= 5
b=4
c=8
d=not (c<=a+b)
print(d)